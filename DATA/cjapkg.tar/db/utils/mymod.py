"""
Example module for Adv Python class

This is a blah blah blah-dy blah

Etc Etc
"""

ANIMALS = ['wombat', 'crocodile', 'platypus', 'bushbaby']

class Thing:
    """
    The thing of it is, the thing.
    """
    pass

def spam():
    """Canned fatty pork substance"""
    print("Hello from spam()")

def _toast():
    print("    _toasting...")

def ham():
    """Delicious smoked pig leg (use jackfruit if vegan)"""
    print("In ham()")
    _toast()


