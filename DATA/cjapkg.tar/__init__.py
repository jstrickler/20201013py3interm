"""
Python framework for CJ Associates

Abandon hope, all ye who enter here

Reasons for __init__.py in a package
1. Documentation (this)
2. Initialization code
3. Convenience imports
"""
# this is the package namespace

COLOR = 'green'

from cja.db.utils.mymod import spam


